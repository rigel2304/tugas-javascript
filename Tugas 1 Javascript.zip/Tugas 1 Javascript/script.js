// Fungsi untuk menghitung luas persegi panjang (Rumus: panjang * lebar)
function hitungLuasPersegiPanjang(panjang, lebar) {
    let luas = panjang * lebar; // Menggunakan variabel dan operator perkalian
    console.log("Luas persegi panjang (p: " + panjang + ", l: " + lebar + ") = " + luas);
    return luas;
}

// Fungsi untuk menghitung luas bujur sangkar / persegi (Rumus: sisi * sisi)
function hitungLuasBujurSangkar(sisi) {
    let luas = sisi * sisi; // Menggunakan variabel dan operator perkalian
    console.log("Luas bujur sangkar (sisi: " + sisi + ") = " + luas);
    return luas;
}

// Fungsi untuk menghitung luas segitiga (Rumus: 0.5 * alas * tinggi)
function hitungLuasSegitiga(alas, tinggi) {
    let luas = 0.5 * alas * tinggi; // Menggunakan variabel dan operator perkalian
    console.log("Luas segitiga (alas: " + alas + ", tinggi: " + tinggi + ") = " + luas);
    return luas;
}

// Contoh pemanggilan fungsi dengan nilai argumen bebas
hitungLuasPersegiPanjang(10, 5);
hitungLuasBujurSangkar(7);
hitungLuasSegitiga(8, 6);