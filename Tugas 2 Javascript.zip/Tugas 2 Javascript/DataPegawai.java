public class DataPegawai {
    public static void main(String[] args) {
        // Diketahui
        String nama = "Dodi Prayodi";
        int umur = 25;
        String jabatan = "Manajer";
        String status = "Menikah";
        
        // Gaji Pokok
        double gajiPokok = 15000000;
        
        // Perhitungan Komponen Gaji
        double tunjanganJabatan = 0.15 * gajiPokok;
        double bpjs = 0.10 * gajiPokok;
        
        // Tunjangan Keluarga (ternary)
        double tunjanganKeluarga = status.equalsIgnoreCase("menikah") ? (0.20 * gajiPokok) : 0;
        
        // Total Gaji
        double totalGaji = gajiPokok + tunjanganJabatan + tunjanganKeluarga - bpjs;

        // Cetak Output
        System.out.println("=== DATA PEGAWAI ===");
        System.out.println("Nama Pegawai      : " + nama);
        System.out.println("Umur              : " + umur + " tahun");
        System.out.println("Jabatan           : " + jabatan);
        System.out.println("Status            : " + status);
        System.out.println("Gaji Pokok        : Rp " + (int)gajiPokok);
        System.out.println("Tunjangan Jabatan : Rp " + (int)tunjanganJabatan);
        System.out.println("BPJS              : Rp " + (int)bpjs);
        System.out.println("Tunjangan Keluarga: Rp " + (int)tunjanganKeluarga);
        System.out.println("-----------------------------------");
        System.out.println("Total Gaji        : Rp " + (int)totalGaji);
    }
}