class Pelanggan {
    constructor(nama, nomorTelepon, kendaraanDisewa) {
        this.nama = nama;
        this.nomorTelepon = nomorTelepon;
        this.kendaraanDisewa = kendaraanDisewa;
    }

    sewaKendaraan(kendaraan) {
        this.kendaraanDisewa = kendaraan;
    }

    tampilkanData() {
        console.log('Nama: ${this.nama}');
        console.log('Nomor Telepon: ${this.nomorTelepon}');
        console.log('Kendaraan Disewa: ${this.kendaraanDisewa}');
        console.log("----------------");

    }
}

let daftarPelanggan = [];
let pelanggan1 = new Pelanggan(
    "Budi",
    "081234567890",
    "Toyota Avanza"
);
let pelanggan2 = new Pelanggan(
    "Siti",
    "082345678901",
    "Honda Brio"
);
let pelanggan3 = new Pelanggan(
    "Andi",
    "083456789012",
    "Mitsubishi Xpander"
);

daftarPelanggan.push(pelanggan1);
daftarPelanggan.push(pelanggan2);
daftarPelanggan.push(pelanggan3);
console.log("=== DAFTAR PELANGGAN ===");
daftarPelanggan.forEach(function(pelanggan) {
    pelanggan.tampilkanData();
});