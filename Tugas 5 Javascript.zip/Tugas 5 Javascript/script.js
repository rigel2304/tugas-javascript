// **Data produk**
let produkList = [
    { id: 1, nama: "Laptop", harga: 12000000 },
    { id: 2, nama: "Smartphone", harga: 5000000 },
    { id: 3, nama: "Tablet", harga: 7000000 },
    { id: 4, nama: "Headset", harga: 750000 },
    { id: 5, nama: "Keyboard", harga: 500000 }
];

// Nama fungsi 
const eventHandler = {
    tambah: tambahProduk,
    hapus: hapusProduk,
    tampil: tampilkanProduk
};

// **Menambahkan produk dengan spread operator**
function tambahProduk(id, nama, harga) {
    const produkBaru = {
        id,
        nama,
        harga
    };
    produkList = [...produkList, produkBaru];
    console.log("Produk berhasil ditambahkan!");
}

// **Menghapus produk dengan rest parameter**
function hapusProduk(id) {
    produkList = produkList.filter(
        produk => produk.id !== id
    );
    console.log("Produk berhasil dihapus!");
}

// **Menampilkan produk dengan destructuring**
function tampilkanProduk() {
    console.log("=== DAFTAR PRODUK ===");
    produkList.forEach(({ id, nama, harga }) => {
        console.log(
            `ID: ${id}, Nama: ${nama}, Harga: Rp${harga}`
        );

    });
}

// Menampilkan produk awal
tampilkanProduk();

// Contoh penambahan data
tambahProduk(6, "Mouse", 300000);
tampilkanProduk();

// Menghapus produk ID 2 
hapusProduk(2);
tampilkanProduk();

