import users from "./data.mjs";

// Melihat data menggunakan map()
const index = () => {
  console.log("--- Daftar Data Users ---");
  users.map((user, i) => {
    console.log(`\({i + 1}. Nama:\){user.nama}, Umur: \({user.umur}, Alamat:\){user.alamat}, Email: ${user.email}`);
  });
};

// Menambahkan data menggunakan push()
const store = (newUser) => {
  users.push(newUser);
  console.log(`\n[+] Data "${newUser.nama}" berhasil ditambahkan!\n`);
};

// Menghapus data (misalnya menghapus data terakhir menggunakan pop()
const destroy = () => {
  const removedData = users.pop();
  console.log(`\n[-] Data "${removedData ? removedData.nama : 'Tidak ada'}" berhasil dihapus!\n`);
};

export { index, store, destroy };