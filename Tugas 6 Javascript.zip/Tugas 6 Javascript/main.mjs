import { index, store, destroy } from "./controller.mjs";

const main = () => {
  // Tampilkan data awal
  console.log("=== DATA AWAL ===");
  index();

  // Tambah minimal 2 data baru menggunakan store (push)
  console.log("\n=== PROSES PENAMBAHAN DATA ===");
  store({ nama: 'Data Baru 1', umur: 30, alamat: 'Jl. Baru 1', email: 'baru1@email.com' });
  store({ nama: 'Data Baru 2', umur: 31, alamat: 'Jl. Baru 2', email: 'baru2@email.com' });

  // Tampilkan data setelah penambahan
  console.log("=== DATA SETELAH DITAMBAHKAN ===");
  index();

  // Hapus data (destroy)
  console.log("\n=== PROSES PENGHAPUSAN DATA ===");
  destroy();

  // Tampilkan data akhir setelah penghapusan
  console.log("=== DATA AKHIR SETELAH PENGHAPUSAN ===");
  index();
};

main();